import socket
import logging
import time


def daytime():
    day = time.localtime()
    day = str(day[2]) + "." + str(day[1]) + "." + str(day[0]) + "-" + str(day[3]) + ":" + str(day[4]) + ":" + str(day[5])
    return day


class Server():

    def __init__(self, host, port):
        logging.basicConfig(filename='log.txt', level=logging.WARNING)
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        #print 'Socket created'
        try:
            s.bind((host, port))
        except socket.error, msg:
            logging.error(daytime() + ' Bind failed. Error code: ' + str(msg[0]) + 'Error message: ' + msg[1])
        #print 'Socket bind complete'
        s.listen(1)
        #print 'Socket now listening'
        try:
            while True:
                con, addr = s.accept()
                while True:
                    data = con.recv(1024)

                    if not data:
                        con.close()
                        break
                    #print "Adress: " + str(addr[0])
                    #print "Data: " + str(data)
                    self.handle(addr[0], data)
        finally:
            s.close()

    def handle(self, cli, data):
        pass