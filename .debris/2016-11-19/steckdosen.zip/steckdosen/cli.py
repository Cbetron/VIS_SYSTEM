import socket
import time


def switch(ip, port, data, lenght, protocol):
    try:
        output = "," + str(data) + "," + str(lenght) + "," + str(protocol) + ","
        s = socket.socket()
        s.connect((ip, port))
        s.send(output)
    finally:
        s.close()


while True:
    switch('192.168.188.49', 5777, 647000256, 32, 2)    #on
    #switch('192.168.188.49', 5777, 1049937, 24, 1)
    time.sleep(5)
    switch('192.168.188.49', 5777, 781217984, 32, 2)    #off
    #switch('192.168.188.49', 5777, 1049940, 24, 1)
    time.sleep(5)