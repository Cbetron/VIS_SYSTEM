#Port: 5777


import threading
import Queue
import string
import logging
import time
import serial
from Server import Server


allowed = ['127.0.0.1', '192.168.188.86']


#Erstellt den Zeitstempel
def daytime():
    day = time.localtime()
    day = str(day[2]) + "." + str(day[1]) + "." + str(day[0]) + "-" + str(day[3]) + ":" + str(day[4]) + ":" + str(day[5])
    return day


#Die Serielle verbindung zum Sender
class SteckdosenSerial():

    def __init__(self, com, baud):
        logging.basicConfig(filename='log.txt', level=logging.WARNING)
        self.com = com
        self.baud = baud

    def send(self, data, lenght, protocol):
        if data > 0 and lenght > 0 and protocol > 0:
            toSend = "," + str(data) + "," + str(lenght) + "," + str(protocol) + ","
            ser = serial.Serial(self.com, self.baud)
            #print "ToSend: " + str(toSend)
            ser.write(toSend)
            ser.close()
        else:
            logging.error(daytime() + " Wrong Data!")


#Server Programm
class Steckdosen(Server):
    def handle(self, cli, data):
        for a in allowed:
            if cli == a:
                split = string.split(data, ",")
                if len(split) == 5:
                    qThread.q.put((cli, split))
                break


#Warteschlange fuer eingehende befehle
class QThread(threading.Thread):
    q = Queue.Queue()

    def __init__(self):
        threading.Thread.__init__(self)

    def run(self):
        while True:
            rec = self.q.get()
            data = rec[1]
            stSer.send(data[1], data[2], data[3])
            self.q.task_done()


if __name__ == "__main__":
    qThread = QThread()
    qThread.daemon = True
    qThread.start()
    stSer = SteckdosenSerial('/dev/ttyACM0', 9600)
    #stSer = SteckdosenSerial('COM4', 9600)
    server = Steckdosen('', 5777)